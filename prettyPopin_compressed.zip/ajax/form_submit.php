<p>Post content</p>
<pre style="width: 300px">
<?php print_r($_POST) ?>
</pre>